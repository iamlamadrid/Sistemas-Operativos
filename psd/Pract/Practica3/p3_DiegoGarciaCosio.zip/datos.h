#define M 10//filas
#define N 4 // columnas
#define K 10 // rango de valores
#define V 5 //iteraciones por hilo de relleno
