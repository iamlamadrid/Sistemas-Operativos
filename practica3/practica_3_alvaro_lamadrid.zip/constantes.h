#include <stdlib.h>
#include <time.h>
#include <malloc.h>
#include <pthread.h>

#define TAB 64 // posiciones que habra en el tablero
#define NUM_JUGADAS_MAX 120 // numero maximo de jugadas quese pueden realizar