#include<stdlib.h>
#include<stdio.h>
#include<time.h>
#include<unistd.h>
#include<signal.h>
#include<limits.h>
#include<float.h>
#include<sys/wait.h>

#define PASOS 4